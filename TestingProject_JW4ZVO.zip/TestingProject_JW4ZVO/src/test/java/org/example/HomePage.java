package org.example;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import java.util.List;
import java.util.Optional;

public class HomePage {

    private static final String PAGE_URL = "https://www.saucedemo.com/";

    public static final By USERNAME = By.id("user-name");
    public static final By PASSWORD = By.id("password");
    public static final By FIRSTNAME = By.id("first-name");
    public static final By LASTNAME = By.id("last-name");
    public static final By POSTAL_CODE = By.id("postal-code");

    private static final By LOGIN_ERROR = By.xpath("/html/body/div/div/div[2]/div[1]/div[1]/div/form/div[3]/h3");

    @FindBy(id = "user-name")
    private WebElement username;

    @FindBy(id = "password")
    private WebElement password;

    @FindBy(id = "login-button")
    private WebElement loginButton;

    @FindBy(id = "add-to-cart-sauce-labs-backpack")
    private WebElement addBackpackToCartButton;

    @FindBy(id = "add-to-cart-sauce-labs-bike-light")
    private WebElement addBikeLightToCartButton;

    @FindBy(className = "shopping_cart_link")
    private WebElement shoppingCartLink;

    @FindBy(id = "checkout")
    private WebElement checkoutButton;

    @FindBy(id = "first-name")
    private WebElement firstname;

    @FindBy(id = "last-name")
    private WebElement lastname;

    @FindBy(id = "postal-code")
    private WebElement postalCode;

    @FindBy(id = "continue")
    private WebElement continueButton;

    @FindBy(id = "finish")
    private WebElement finishButton;

    @FindBy(id="back-to-products")
    private WebElement backButton;

    @FindBy(id="remove-sauce-labs-backpack")
    private WebElement removeBackpackButton;

    @FindBy(css = "img[class='inventory_item_img']")
    private WebElement photo;

    @FindBy(className = "summary_total_label")
    private WebElement totalLabel;

    @FindBy( className = "complete-header")
    private WebElement end;

    

    private WebDriver driver;

    public HomePage(WebDriver driver) {
        this.driver = driver;
    }

    public void openPage() {
        driver.get(PAGE_URL);
        PageFactory.initElements(driver, this);
    }

    public void fillField(By locator, String value) {
        getField(locator).sendKeys(value);
    }

    public WebElement getField(By locator) {
        return driver.findElement(locator);
    }

    public void clickLoginButton() {
        loginButton.click();
    }

    public void addBackPackToCart() {
        addBackpackToCartButton.click();
    }

    public void addBikeLightToCart() {
        addBikeLightToCartButton.click();
    }

    public void clickOnCart() {
        shoppingCartLink.click();
    }

    public void clickCheckoutButton() {
        checkoutButton.click();
    }

    public void clickContinueButton() {
        continueButton.click();
    }

    public String getTotal() {
        return totalLabel.getText();
    }

    public void clickFinishButton() {
        finishButton.click();
    }

    public String endDisplayed() { return end.getText();}

    public Optional<String> getLoginError() {
        return getErrorMessage(LOGIN_ERROR);
    }

    public Optional<String> getErrorMessage(By errorLocator) {
        Optional<WebElement> error = getError(errorLocator);
        if (error.isPresent()) {
            WebElement errorElement = error.get();
            return Optional.of(errorElement.getText());
        } else {
            return Optional.empty();
        }
    }

    private Optional<WebElement> getError(By errorLocator) {
        List<WebElement> elements = driver.findElements(errorLocator);
        if (elements.size() > 0) {
            return Optional.of(elements.get(0));
        } else {
            return Optional.empty();
        }
    }


    public String checkPhotos() {
        return photo.getAttribute("src");
    }

    public void addToCart(String arg0) {
        driver.findElement(By.id(arg0)).click();
    }

    public void checkPrice(String arg0) {

    }

    public void clickHomeButton() {
              backButton.click();
    }

    public void removeBackpackButton() {
        removeBackpackButton.click();
    }
}
