package org.example;

import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import io.github.bonigarcia.wdm.WebDriverManager;
import org.junit.Assert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.support.ui.Select;

import java.util.Optional;
import java.util.concurrent.TimeUnit;

import static org.junit.Assert.fail;

public class DefFeatureOne {

    private static final int WAIT_TIME = 10;

    static WebDriver driver;

    private static HomePage homePage;

    static {
        WebDriverManager.firefoxdriver().setup();
        driver = new FirefoxDriver();
        driver.manage().timeouts().implicitlyWait(WAIT_TIME, TimeUnit.SECONDS);
        homePage = new HomePage(driver);
    }

    @And("the Password is filled with {string}")
    public void thePasswordIsFilledWithSecret_sauce(String password) {
        homePage.fillField(HomePage.PASSWORD, password);
    }

    @Given("the homepage is open")
    public void theHomepageIsOpen() {
        homePage.openPage();
    }

    @And("the Username is filled with {string}")
    public void theUsernameIsFilledWithStandard_user(String userName) {
        homePage.fillField(HomePage.USERNAME, userName);
    }

    @And("the Login button is clicked")
    public void theLoginButtonIsClicked() {
        homePage.clickLoginButton();
    }

    @Given("the Sauce Labs Backpack is added to the cart")
    public void theSauceLabsBackpackIsAddedToTheCart() {
        homePage.addBackPackToCart();
    }

    @And("the cart icon is clicked")
    public void theCartIconIsClicked() {
        homePage.clickOnCart();
    }

    @And("the checkout button is clicked")
    public void theCheckoutButtonIsClicked() {
        homePage.clickCheckoutButton();
    }

    @And("the First Name is filled with {string}")
    public void theFirstNameIsFilledWithA(String firstName) {
        homePage.fillField(HomePage.FIRSTNAME, firstName);
    }

    @And("the Last Name is filled with {string}")
    public void theLastNameIsFilledWithB(String lastName) {
        homePage.fillField(HomePage.LASTNAME, lastName);
    }

    @And("the Zip Code is filled with {string}")
    public void theZipCodeIsFilledWith(String zipCode) {
        homePage.fillField(HomePage.POSTAL_CODE, zipCode);
    }

    @When("the Continue button is clicked")
    public void theContinueButtonIsClicked() {
        homePage.clickContinueButton();
    }

    @Then("{string} should be shown")
    public void total$ShouldBeShown(String total) {
        Assert.assertEquals(total, homePage.getTotal());
    }

    @Then("{string} should be displayed")
    public void ShouldBeDisplayed(String end) {
        Assert.assertEquals(end,homePage.endDisplayed());
    }

    @Then("the error will be {string}")
    public void theErrorWillBeOutput(String output) {
        Optional<String> errorMessage = homePage.getLoginError();
        if (errorMessage.isPresent()) {
            Assert.assertEquals(output, errorMessage.get());
        } else {
            fail();
        }
    }

    @And("the Sauce Labs Bike Light is added to the cart")
    public void theSauceLabsBikeLightIsAddedToTheCart() {
        homePage.addBikeLightToCart();
    }

    @When("the Finish button is clicked")
    public void theFinishButtonIsClicked() {
        homePage.clickFinishButton();
    }

    @Then("there is a problem on the photos displayed")
    public void thereIsAProblemOnThePhotosDisplayed() {
        Assert.assertEquals("https://www.saucedemo.com/static/media/sl-404.168b1cce.jpg", homePage.checkPhotos());
    }

    @And("the {string} is added to cart")
    public void theItemIsAddedToCart(String arg0) {
        homePage.addToCart(arg0);
    }

    @Then("the {string} is displayed")
    public void thePriceIsDisplayed(String arg0) { Assert.assertEquals(arg0, homePage.getTotal());
    }

    @Then("the Back home button is clicked")
    public void theBackHomeButtonIsClicked() {
        homePage.clickHomeButton();
    }

    @When("the Sauce Labs Backpack is removed")
    public void theSauceLabsBackpackIsRemoved() {
        homePage.removeBackpackButton();
    }

    @When("the sort is set on {string}")
    public void theSortIsSetOn(String arg0) {
        Select sort = new Select(driver.findElement(By.className("product_sort_container")));
        sort.selectByVisibleText(arg0);
    }

    @Then("it should be sorted")
    public void itShouldBeSorted() {
    }
}
