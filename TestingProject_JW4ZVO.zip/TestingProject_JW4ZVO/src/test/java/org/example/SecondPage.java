package org.example;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import static org.example.DefFeatureTwo.driver;

public class SecondPage {

    public static final By NAME2 = By.name("name");

    public static final By PHONE = By.xpath("/html/body/div[4]/div/div/div/div/div/form/fieldset[2]/input");

    public static final By EMAIL2 = By.xpath("/html/body/div[4]/div/div/div/div/div/form/fieldset[3]/input");

    public static final By CITY = By.xpath("/html/body/div[4]/div/div/div/div/div/form/fieldset[5]/input");

    public static final By USERNAME = By.name("username");

    public static final By PASSWORD = By.name("password");
    private static final String PAGE_URL = "https://ultimateqa.com/automation/";

    private static final String PAGE_URL_TWO = "https://www.way2automation.com/demo.html";


    public static final By NAME = By.id("et_pb_contact_name_0");

    public static final By EMAIL = By.id("et_pb_contact_email_0");

    public static final By MESSAGE = By.id("et_pb_contact_message_0");

    public static final By CAPTCHA = By.xpath("/html/body/div[1]/div/div/div/article/div/div[1]/div/div/div[7]/div[2]/div[1]/div[2]/form/div/div/p/input");


    @FindBy(linkText = "Big page with many elements")
    private WebElement bigButton;

    @FindBy(xpath = "//*[@id=\"load_form\"]/div[1]/div[2]/input")
    private WebElement subButton;

    @FindBy(className = "et_pb_contact_message")
    private WebElement message;

    @FindBy(linkText = "Registration")
    private WebElement registrationButton;

    @FindBy(css = "button[class='et_pb_contact_submit et_pb_button']")
    private WebElement submitButton;

    @FindBy(xpath = "/html/body/div[1]/div/div/div/article/div/div[1]/div/div/div[7]/div[2]/div[1]/div[1]/ul/li")
    private WebElement answer;

    public SecondPage() {
    }

    public void openPage() {
        driver.get(PAGE_URL);
        PageFactory.initElements(driver, this);
    }

    public void BigButton() {
        bigButton.click();
    }

    public void fillField(By locator, String value) {
        getField(locator).sendKeys(value);
    }

    public WebElement getField(By locator) {
        return driver.findElement(locator);
    }

    public void submitButton() {
        submitButton.click();
    }


    public String getMessage() {
        return answer.getText();
    }

    public void openThirdPage() {
        driver.get(PAGE_URL_TWO);
        PageFactory.initElements(driver, this);
    }

    public void linkRegistration() {
        registrationButton.click();
    }

    public void submitButtinClick() {
        subButton.click();
    }
}
