package org.example;

import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import io.github.bonigarcia.wdm.WebDriverManager;
import org.junit.Assert;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;

import java.util.concurrent.TimeUnit;

public class DefFeatureTwo {

    private static final int WAIT_TIME = 10;

    static WebDriver driver;

    private static SecondPage secondPage;

    static {
        WebDriverManager.firefoxdriver().setup();
        driver = new FirefoxDriver();
        driver.manage().timeouts().implicitlyWait(WAIT_TIME, TimeUnit.SECONDS);
        secondPage = new SecondPage();
    }

    @Given("the website is opened")
    public void theWebsiteIsOpened() { secondPage.openPage();}

    @Given("the big page button is pressed")
    public void theBigPageButtonIsPressed() { secondPage.BigButton();
    }

    @And("the name is filled with {string}")
    public void theNameIsFilledWithArthur(String arg0) {
        secondPage.fillField(secondPage.NAME, arg0);
    }

    @And("the email is filled with {string}")
    public void theEmailIsFilledWithEmailGmailCom(String arg0) {
        secondPage.fillField(secondPage.EMAIL, arg0);
    }

    @And("the message is filled with {string}")
    public void theMessageIsFilledWithTest(String arg0) {
        secondPage.fillField(secondPage.MESSAGE, arg0);
    }

    @And("the captcha is filled with {string}")
    public void theCaptchaIsFilled(String arg0) {
        secondPage.fillField(secondPage.CAPTCHA, arg0);
    }

    @When("submit button is clicked")
    public void submitButtonIsClicked() { secondPage.submitButton();
    }

    @Then("{string} is displayed")
    public void insideOfToggleIsDisplayed(String arg0) {
        Assert.assertEquals(arg0, secondPage.getMessage());
    }


 /* ---------- THIRD WEBSITE --------------- */
    @Given("the website is launched")
    public void theWebsiteIsLaunched() {
        secondPage.openThirdPage();
    }

    @Given("the registration is clicked")
    public void theRegistrationIsClicked() {
        secondPage.linkRegistration();
    }

    @And("the name field is filled with {string}")
    public void theNameFieldIsFilledWithArthur(String arg0) {
        secondPage.fillField(secondPage.NAME2,arg0);
    }

    @And("the phone field is filled with {string}")
    public void thePhoneFieldIsFilledWith(String arg0) {
        secondPage.fillField(secondPage.PHONE, arg0);
    }

    @And("the email filed is filled {string}")
    public void theEmailFiledIsFilledMailGmailCom(String arg0) {
        secondPage.fillField(secondPage.EMAIL2, arg0);
    }

    @And("the city field is filled with {string}")
    public void theCityFieldIsFilledWithDebrecen(String arg0) {
        secondPage.fillField(secondPage.CITY, arg0);
    }

    @And("the username field is filled with {string}")
    public void theUsernameFieldIsFilledWithUser(String arg0) {
        secondPage.fillField(secondPage.USERNAME, arg0);
    }

    @And("the password field is filled with {string}")
    public void thePasswordFieldIsFilledWithSecret(String arg0) {
        secondPage.fillField(secondPage.PASSWORD, arg0);
    }

    @When("the submit button is clicked")
    public void theSubmitButtonIsClicked() {
        secondPage.submitButtinClick();
    }

    @Then("{string} should be on the screen")
    public void thisIsJustADummyFormYouJustClickedSUBMITBUTTONShouldBeOnTheScreen(String arg0) {
    }
}
